//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// checkpoint_manager.cpp
//
// Identification: src/recovery/checkpoint_manager.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "recovery/checkpoint_manager.h"

namespace bustub {

void CheckpointManager::BeginCheckpoint() {
  // Block all the transactions and ensure that both the WAL and all dirty buffer pool pages are persisted to disk,
  // creating a consistent checkpoint. Do NOT allow transactions to resume at the end of this method, resume them
  // in CheckpointManager::EndCheckpoint() instead. This is for grading purposes.
  LOG_DEBUG("Start checkpoint\n");
  transaction_manager_->BlockAllTransactions();
  LOG_DEBUG("Finish block txns\n");
  buffer_pool_manager_->FlushAllPages();
  LOG_DEBUG("Finish bpm flush\n");
  log_manager_->TriggerFlush(log_manager_->GetNextLSN() - 1);
}

void CheckpointManager::EndCheckpoint() {
  // Allow transactions to resume, completing the checkpoint.
  LOG_DEBUG("Finish checkpoint\n");
  transaction_manager_->ResumeTransactions();
}

}  // namespace bustub
